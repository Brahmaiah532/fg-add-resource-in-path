# "fg-add-resource-in-path" Policy

### Prerequisites 


### Set your anypoint CLI 

anypoint-cli-v4 conf client_id 4e746e************bf948
anypoint-cli-v4 conf client_secret 952EC9B**********03092d36a
anypoint-cli-v4 conf organization bd145f92-4f43-4092-953d-af4d04f18286 (Business group ID)

anypoint-cli-v4 account:environment:list

    - Tip if you are getting 500 go out of vpn

### How can i build this. 

- Pre reqs - https://docs.mulesoft.com/pdk/latest/policies-pdk-prerequisites

- See the docs at https://docs.mulesoft.com/pdk/latest/policies-pdk-create-project

- anypoint-cli-v4 pdk policy-project create -n 'FG Add Resource In Path' -d 'This policy will append the given resource to the context path'  -o  fg-add-resorce-in-path --version=1.0.0

- make setup (For settingup project structure)

- make build / cargo build (To build the project)

- src > lib.rs (To write your code)

- definition > gcl.yaml to write your policy definition

- make run (to run the project locally - you need to setup stuff in plaground - https://docs.mulesoft.com/pdk/latest/policies-pdk-debug-local)

- make release (To push your code to anypoint)


### What are all the business groups we are releasing 

API Integration Platform Team (ea21d5c9-afe6-472c-a994-a0471c749549)
CS-Dtit (bd145f92-4f43-4092-953d-af4d04f18286)
CS-Commercial(243d0ce0-0e7d-4b3a-a799-b1e044e37ee2)
CS-Product Supply (d296b8d4-5bc7-4223-943f-8b909dab53e5)
CS-Research and Development(3d3c20df-5977-4cc1-82f2-1055830a050a)

### How to release without creating new project 

  - API Integration Platform Team
    - group_id = "ea21d5c9-afe6-472c-a994-a0471c749549"
    - anypoint-cli-v4 conf organization ea21d5c9-afe6-472c-a994-a0471c749549
  - cs-dtit
     - group_id = "bd145f92-4f43-4092-953d-af4d04f18286"
     - anypoint-cli-v4 conf organization bd145f92-4f43-4092-953d-af4d04f18286
  - CS-Commercial
    - group_id = "243d0ce0-0e7d-4b3a-a799-b1e044e37ee2"
    - anypoint-cli-v4 conf organization 243d0ce0-0e7d-4b3a-a799-b1e044e37ee2
  - PH-Commercial
    - group_id = "918c7335-a58c-4798-b095-a83621914da9"
    - anypoint-cli-v4 conf organization 918c7335-a58c-4798-b095-a83621914da9
  - EF-Shared
    - group_id = "f8930ae6-825b-4142-849e-6ad31a5ea504"
    - anypoint-cli-v4 conf organization f8930ae6-825b-4142-849e-6ad31a5ea504
  - CS-Research and Development
    - group_id = "3d3c20df-5977-4cc1-82f2-1055830a050a"
    - anypoint-cli-v4 conf organization 3d3c20df-5977-4cc1-82f2-1055830a050a
  - CS-Product and Supply
    - group_id = "d296b8d4-5bc7-4223-943f-8b909dab53e5"
     - anypoint-cli-v4 conf organization d296b8d4-5bc7-4223-943f-8b909dab53e5
  - CH-Product and Pipeline - RnD RMSC
     - group_id = "439f2627-49ec-4b25-bd0e-97a66e56aed9"
     - anypoint-cli-v4 conf organization 439f2627-49ec-4b25-bd0e-97a66e56aed9
  - PH-Shared
    - group_id = "fe302f98-155a-48b0-b74b-67abf2abef7b"
    - anypoint-cli-v4 conf organization fe302f98-155a-48b0-b74b-67abf2abef7b
  - CH-Shared
    - group_id = "cd9a0076-6ebc-4e1c-80ec-ff799ef482af"
    - anypoint-cli-v4 conf organization cd9a0076-6ebc-4e1c-80ec-ff799ef482af
  - Playground
    - group_id = "c6bfe2dd-7c75-4704-954a-24924ba06b10"
    - anypoint-cli-v4 conf organization c6bfe2dd-7c75-4704-954a-24924ba06b10  - 